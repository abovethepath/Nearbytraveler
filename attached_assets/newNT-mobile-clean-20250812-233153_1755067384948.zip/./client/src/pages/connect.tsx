import { useContext, useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { AuthContext } from "@/App";
import TravelMatches from "@/components/travel-matches";
import UserCard from "@/components/user-card";
import ResponsiveUserGrid from "@/components/ResponsiveUserGrid";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Users, Heart, MapPin, Calendar as CalendarIcon, TrendingUp, ArrowLeft, Edit, Filter, ChevronDown, ChevronRight, Search, X, MessageCircle } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { getAllInterests, getAllActivities, getAllEvents, getAllLanguages, validateSelections } from "../../../shared/base-options";
import { BASE_TRAVELER_TYPES } from "@/lib/travelOptions";
import { getInterestStyle, getActivityStyle, getEventStyle } from "@/lib/topChoicesUtils";
import { SEXUAL_PREFERENCE_OPTIONS } from "@/lib/formConstants";

import { formatDateForDisplay } from "@/lib/dateUtils";
import BackButton from "@/components/back-button";
import ConnectModal from "@/components/connect-modal";
import type { User, TravelPlan } from "@shared/schema";
import { SmartLocationInput } from "@/components/SmartLocationInput";



export default function ConnectPage() {
  const [, setLocation] = useLocation();
  const { user } = useContext(AuthContext);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  console.log('ConnectPage - user data:', user?.username, user?.location);
  
  // Active tab state
  const [activeTab, setActiveTab] = useState("ai-matches");
  
  // Connect modal state - auto-open on page load
  const [showConnectModal, setShowConnectModal] = useState(true);
  const [connectModalMode, setConnectModalMode] = useState<'current' | 'hometown'>('current');

  // Handle URL parameters for tab switching
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    if (tabParam === 'advanced-filters') {
      setActiveTab('advanced-filters');
      setShowConnectModal(false); // Close modal when going to advanced filters
      // Clean up URL
      window.history.replaceState({}, '', '/connect');
    }
  }, []);
  


  // Location search state
  const [searchLocation, setSearchLocation] = useState("");
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [showStartCalendar, setShowStartCalendar] = useState(false);
  const [showEndCalendar, setShowEndCalendar] = useState(false);

  // Advanced filters state
  const [advancedFilters, setAdvancedFilters] = useState({
    search: "",
    gender: [] as string[],
    sexualPreference: [] as string[],
    minAge: undefined as number | undefined,
    maxAge: undefined as number | undefined,
    interests: [] as string[],
    activities: [] as string[],
    events: [] as string[],
    location: "",
    userType: [] as string[],
    travelerTypes: [] as string[],
    militaryStatus: [] as string[]
  });

  // Location filter state for SmartLocationInput
  const [locationFilter, setLocationFilter] = useState({
    country: "",
    state: "",
    city: ""
  });
  const [advancedSearchResults, setAdvancedSearchResults] = useState<User[]>([]);
  const [isAdvancedSearching, setIsAdvancedSearching] = useState(false);
  const [hasAdvancedSearched, setHasAdvancedSearched] = useState(false);

  // User data queries with proper refetch configuration
  const { data: userTravelPlans = [], isLoading: isLoadingTravelPlans, refetch: refetchTravelPlans } = useQuery({
    queryKey: [`/api/travel-plans/${user?.id}`],
    enabled: !!user?.id,
    staleTime: 0, // Always consider data stale for fresh fetches
    gcTime: 5 * 60 * 1000, // Keep in cache for 5 minutes
    refetchOnMount: true,
    refetchOnWindowFocus: true,
  });
  

  
  // Refetch travel plans when component mounts or user changes
  useEffect(() => {
    if (user?.id) {
      refetchTravelPlans();
    }
  }, [user?.id, refetchTravelPlans]);



  // Initialize location based on user data
  useEffect(() => {
    if (user && !searchLocation) {
      const currentLocation = user.location || user.hometownCity || "";
      setSearchLocation(currentLocation);
    }
  }, [user, searchLocation]);

  // Get user's location helper
  const getUserLocation = (mode: 'current' | 'hometown') => {
    if (!user) return "";
    
    if (mode === 'hometown') {
      // Build hometown from city, state, country
      const parts = [];
      if (user.hometownCity) parts.push(user.hometownCity);
      if (user.hometownState) parts.push(user.hometownState);
      if (user.hometownCountry && user.hometownCountry !== 'United States') parts.push(user.hometownCountry);
      return parts.join(', ') || "";
    } else {
      // Check if user is currently traveling based on any active travel plan
      const now = new Date();
      
      // Check all travel plans to find current destination
      if (userTravelPlans && userTravelPlans.length > 0) {
        const currentTrip = userTravelPlans.find((plan: TravelPlan) => {
          if (!plan.startDate || !plan.endDate) return false;
          const start = new Date(plan.startDate);
          const end = new Date(plan.endDate);
          return now >= start && now <= end;
        });
        
        if (currentTrip) {
          return currentTrip.destination;
        }
      }
      
      // Fallback to stored travel destination
      if (user.travelStartDate && user.travelEndDate && user.travelDestination) {
        const travelStart = new Date(user.travelStartDate);
        const travelEnd = new Date(user.travelEndDate);
        if (now >= travelStart && now <= travelEnd) {
          return user.travelDestination;
        }
      }
      
      // Otherwise show their regular location
      return user.location || "";
    }
  };

  // Location search functionality
  const searchMutation = useMutation({
    mutationFn: async (): Promise<User[]> => {
      if (!searchLocation.trim()) {
        throw new Error("Please enter a location to search");
      }
      
      const params = new URLSearchParams({
        location: searchLocation.trim(),
        ...(startDate && { startDate: startDate.toISOString().split('T')[0] }),
        ...(endDate && { endDate: endDate.toISOString().split('T')[0] })
      });
      
      console.log('ConnectModal searching for:', searchLocation.trim());
      const response = await fetch(`/api/users/search-by-location?${params}`);
      if (!response.ok) {
        throw new Error('Failed to search for travelers and locals');
      }
      const results = await response.json();
      console.log('ConnectModal search results:', results);
      return results;
    },
    onSuccess: (data: User[]) => {
      console.log('ConnectModal onSuccess with data:', data);
      setSearchResults(data);
      setIsSearching(false);
      setHasSearched(true);
    },
    onError: (error: any) => {
      console.error('ConnectModal search error:', error);
      toast({
        title: "Search Error",
        description: error.message || "Failed to search for travelers",
        variant: "destructive",
      });
      setIsSearching(false);
    },
  });

  const handleSearch = () => {
    setIsSearching(true);
    searchMutation.mutate();
  };

  const handleTravelPlanSelect = (plan: TravelPlan) => {
    setSearchLocation(plan.destination);
    if (plan.startDate) setStartDate(new Date(plan.startDate));
    if (plan.endDate) setEndDate(new Date(plan.endDate));
    setSearchResults([]);
    setHasSearched(false);
  };

  // Advanced search function
  const handleAdvancedSearch = async () => {
    setIsAdvancedSearching(true);
    setHasAdvancedSearched(true);
    
    try {
      console.log('Performing advanced search with filters:', advancedFilters);
      
      // Build query parameters for the search
      const params = new URLSearchParams();
      
      if (advancedFilters.search) params.append('search', advancedFilters.search);
      if (advancedFilters.gender.length > 0) params.append('gender', advancedFilters.gender.join(','));
      if (advancedFilters.sexualPreference.length > 0) params.append('sexualPreference', advancedFilters.sexualPreference.join(','));
      if (advancedFilters.minAge) params.append('minAge', advancedFilters.minAge.toString());
      if (advancedFilters.maxAge) params.append('maxAge', advancedFilters.maxAge.toString());
      if (advancedFilters.interests.length > 0) params.append('interests', advancedFilters.interests.join(','));
      if (advancedFilters.activities.length > 0) params.append('activities', advancedFilters.activities.join(','));
      if (advancedFilters.events.length > 0) params.append('events', advancedFilters.events.join(','));
      if (advancedFilters.location) params.append('location', advancedFilters.location);
      if (advancedFilters.userType.length > 0) params.append('userType', advancedFilters.userType.join(','));
      if (advancedFilters.travelerTypes.length > 0) params.append('travelerTypes', advancedFilters.travelerTypes.join(','));
      if (advancedFilters.militaryStatus.length > 0) params.append('militaryStatus', advancedFilters.militaryStatus.join(','));
      
      const response = await fetch(`/api/users/search?${params.toString()}`);
      
      const data = await response.json();
      console.log('Advanced search results:', data);
      setAdvancedSearchResults(data || []);
      
      toast({
        title: "Search Complete",
        description: `Found ${data?.length || 0} users matching your criteria`,
      });
    } catch (error) {
      console.error('Advanced search error:', error);
      toast({
        title: "Search Error",
        description: "Failed to search users. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAdvancedSearching(false);
    }
  };

  // Clear advanced filters
  const clearAdvancedFilters = () => {
    setAdvancedFilters({
      search: "",
      gender: [],
      sexualPreference: [],
      minAge: undefined,
      maxAge: undefined,
      interests: [],
      activities: [],
      events: [],
      location: "",
      userType: [],
      travelerTypes: [],
      militaryStatus: []
    });
    setAdvancedSearchResults([]);
    setHasAdvancedSearched(false);
  };



  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <BackButton />
        </div>

        {/* Quick Connect Section */}
        <Card 
          className="mb-6 cursor-pointer hover:shadow-md transition-shadow"
          onClick={() => {
            setConnectModalMode('current');
            setShowConnectModal(true);
          }}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-600" />
              Quick Connect
            </CardTitle>
            <p className="text-gray-600 dark:text-gray-300">Connect with travelers and locals in your destinations</p>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-3 mb-4">
              {/* Current Travel Destination (if traveling) */}
              {(() => {
                const currentLocation = getUserLocation('current');
                const hometown = getUserLocation('hometown');
                const isCurrentlyTraveling = currentLocation !== user?.location;
                
                if (isCurrentlyTraveling && currentLocation) {
                  return (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setActiveTab("location-search");
                        setSearchLocation(currentLocation);
                        setStartDate(undefined);
                        setEndDate(undefined);
                        setSearchResults([]);
                        setHasSearched(false);
                        setTimeout(() => handleSearch(), 100);
                      }}
                      className="flex items-center gap-2 bg-blue-50 border-blue-200"
                    >
                      <MapPin className="w-4 h-4 text-blue-600" />
                      ✈️ Currently in {currentLocation.split(',')[0]}
                    </Button>
                  );
                }
                return null;
              })()}
              
              {/* Hometown */}
              {getUserLocation('hometown') && (
                <Button
                  variant="outline"
                  onClick={() => {
                    setActiveTab("location-search");
                    setSearchLocation(getUserLocation('hometown'));
                    setStartDate(undefined);
                    setEndDate(undefined);
                    setSearchResults([]);
                    setHasSearched(false);
                    setTimeout(() => handleSearch(), 100);
                  }}
                  className="flex items-center gap-2"
                >
                  <MapPin className="w-4 h-4" />
                  🏠 Hometown {getUserLocation('hometown').split(',')[0]}
                </Button>
              )}
              
              {/* Travel Plans */}
              {isLoadingTravelPlans ? (
                <div className="space-y-2">
                  <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
                  <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
                  <div className="h-10 bg-gray-200 rounded animate-pulse"></div>
                </div>
              ) : userTravelPlans && userTravelPlans.length > 0 ? (
                userTravelPlans.map((plan: TravelPlan) => (
                  <Button
                    key={plan.id}
                    variant="outline"
                    onClick={() => {
                      setActiveTab("location-search");
                      handleTravelPlanSelect(plan);
                      setTimeout(() => handleSearch(), 100);
                    }}
                    className="flex items-center gap-2"
                  >
                    ✈️ {plan.destination}
                    <span className="ml-1 text-sm text-gray-500">
                      {plan.startDate && plan.endDate ? (
                        `${formatDateForDisplay(plan.startDate, "SHORT")} - ${formatDateForDisplay(plan.endDate, "SHORT")}`
                      ) : plan.startDate ? (
                        `From ${formatDateForDisplay(plan.startDate, "SHORT")}`
                      ) : (
                        "Dates TBD"
                      )}
                    </span>
                  </Button>
                ))
              ) : null}
            </div>
            
            {/* Call to Action Button */}
            <div className="border-t pt-4 text-center">
              <Button 
                onClick={(e) => {
                  e.stopPropagation(); // Prevent card click
                  setConnectModalMode('current');
                  setShowConnectModal(true);
                }}
                className="bg-gradient-to-r from-blue-600 to-orange-500 text-white hover:from-blue-700 hover:to-orange-600 font-semibold px-6 py-3"
                size="lg"
              >
                <Users className="w-5 h-5 mr-2" />
                Connect with Travelers & Locals
              </Button>
              <p className="text-sm text-gray-500 mt-2">Or click anywhere on this card</p>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white/60 dark:bg-gray-800/60 backdrop-blur-xl border border-white/20 dark:border-gray-700/50 rounded-xl p-2">
            <TabsTrigger value="ai-matches" className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-pink-600 data-[state=active]:text-white transition-all duration-300">AI Matches</TabsTrigger>
            <TabsTrigger value="location-search" className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-teal-600 data-[state=active]:text-white transition-all duration-300">Location Search</TabsTrigger>
            <TabsTrigger value="advanced-filters" className="rounded-lg data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-600 data-[state=active]:text-white transition-all duration-300">Advanced Filters</TabsTrigger>
          </TabsList>



          {/* AI Matches Tab - Integrated from Matches page */}
          <TabsContent value="ai-matches" className="space-y-6">
            <Card className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-xl border border-white/20 dark:border-gray-700/50 rounded-2xl shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  AI-Powered Travel Matches
                </CardTitle>
              </CardHeader>
              <CardContent>
                <TravelMatches />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Location Search Tab */}
          <TabsContent value="location-search" className="space-y-6">
            <Card>
              <CardContent className="space-y-6 pt-6">
                {/* Quick Select Buttons */}
                <div>
                  <h3 className="text-sm font-medium mb-2 text-black dark:text-white">Quick Select</h3>
                  <div className="flex flex-wrap gap-2">
                    {/* Current Location */}
                    {getUserLocation('current') && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSearchLocation(getUserLocation('current'));
                          setStartDate(undefined);
                          setEndDate(undefined);
                          setSearchResults([]);
                          setHasSearched(false);
                        }}
                        className="text-xs"
                      >
                        <MapPin className="w-3 h-3 mr-1" />
                        Current ({getUserLocation('current').split(',')[0]})
                      </Button>
                    )}
                    
                    {/* Hometown */}
                    {getUserLocation('hometown') && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSearchLocation(getUserLocation('hometown'));
                          setStartDate(undefined);
                          setEndDate(undefined);
                          setSearchResults([]);
                          setHasSearched(false);
                        }}
                        className="text-xs"
                      >
                        <MapPin className="w-3 h-3 mr-1" />
                        Hometown ({getUserLocation('hometown')})
                      </Button>
                    )}
                    
                    {/* Travel Plans */}
                    {userTravelPlans && userTravelPlans.length > 0 ? (
                      userTravelPlans.map((plan: TravelPlan) => (
                        <Button
                          key={plan.id}
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSearchLocation(plan.destination);
                            if (plan.startDate) setStartDate(new Date(plan.startDate));
                            if (plan.endDate) setEndDate(new Date(plan.endDate));
                            setSearchResults([]);
                            setHasSearched(false);
                            setTimeout(() => handleSearch(), 100);
                          }}
                          className="text-xs"
                        >
                          ✈️ {plan.destination}
                          <span className="ml-1 text-gray-500">
                            {plan.startDate && plan.endDate ? (
                              `${formatDateForDisplay(plan.startDate, "SHORT")} - ${formatDateForDisplay(plan.endDate, "SHORT")}`
                            ) : plan.startDate ? (
                              `From ${formatDateForDisplay(plan.startDate, "SHORT")}`
                            ) : (
                              "Dates TBD"
                            )}
                          </span>
                        </Button>
                      ))
                    ) : (
                      <div className="text-xs text-gray-500">No travel plans found</div>
                    )}
                  </div>
                </div>

                {/* Search Form */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location" className="text-black dark:text-white">Location</Label>
                    <div className="relative">
                      <Input
                        id="location"
                        placeholder="Enter city or destination..."
                        value={searchLocation}
                        onChange={(e) => setSearchLocation(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                      />
                      <MapPin className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-black dark:text-white">Start Date (Optional)</Label>
                    <Popover open={showStartCalendar} onOpenChange={setShowStartCalendar}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {startDate ? format(startDate, "PPP") : "Select start date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={startDate}
                          onSelect={(date) => {
                            setStartDate(date);
                            setShowStartCalendar(false);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-black dark:text-white">End Date (Optional)</Label>
                    <Popover open={showEndCalendar} onOpenChange={setShowEndCalendar}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {endDate ? format(endDate, "PPP") : "Select end date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={endDate}
                          onSelect={(date) => {
                            setEndDate(date);
                            setShowEndCalendar(false);
                          }}
                          disabled={(date) => startDate ? date < startDate : false}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <Button 
                  onClick={handleSearch}
                  disabled={!searchLocation.trim() || isSearching}
                  className="w-full"
                >
                  <Search className="w-4 h-4 mr-2" />
                  {isSearching ? "Searching..." : "Find Locals and Travelers"}
                </Button>

                {/* Search Results */}
                {isSearching && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-black dark:text-white">Searching for travelers...</h3>
                    {[1, 2, 3].map((i) => (
                      <Card key={i}>
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-4">
                            <Skeleton className="h-12 w-12 rounded-full" />
                            <div className="space-y-2 flex-1">
                              <Skeleton className="h-4 w-1/2" />
                              <Skeleton className="h-3 w-3/4" />
                            </div>
                            <Skeleton className="h-8 w-20" />
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}

                {searchResults.length > 0 && (
                  <ResponsiveUserGrid 
                    users={searchResults}
                    title={`Found ${searchResults.length} ${searchResults.length === 1 ? 'person' : 'people'} in ${searchLocation}`}
                  />
                )}

                {hasSearched && searchResults.length === 0 && !isSearching && (
                  <Card>
                    <CardContent className="text-center py-12">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2 text-black dark:text-white">No travelers found</h3>
                      <p className="text-black dark:text-white mb-4">
                        No one is currently traveling to {searchLocation} during your selected dates.
                      </p>
                      <Button variant="outline" onClick={() => setActiveTab("smart-matches")}>
                        Try Smart Matches Instead
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advanced Filters Tab - Exact Copy from Home Page */}
          <TabsContent value="advanced-filters" className="space-y-6">
            <Card className="p-6 bg-gray-50 dark:bg-gray-800">
              {/* Search Bar with Top Search Button */}
              <div className="mb-6 bg-white dark:bg-gray-700 p-4 rounded-lg border dark:border-gray-600 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-700 flex items-center">
                    <Search className="w-4 h-4 mr-2" />
                    Search Users / Key Word Search
                  </label>
                  <Button
                    className="bg-gradient-to-r from-blue-500 to-orange-500 text-white hover:from-blue-600 hover:to-orange-600"
                    size="sm"
                    onClick={handleAdvancedSearch}
                    disabled={isAdvancedSearching}
                  >
                    <Search className="w-4 h-4 mr-2" />
                    {isAdvancedSearching ? "Searching..." : "Search Now"}
                  </Button>
                </div>
                <Input
                  placeholder="Search by name, username, city..."
                  value={advancedFilters.search}
                  onChange={(e) => setAdvancedFilters(prev => ({ ...prev, search: e.target.value }))}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      console.log('Enter pressed - search triggered');
                    }
                  }}
                  className="w-full text-base"
                />
              </div>
              
              <div className="flex flex-col lg:flex-row gap-4 mb-4">
                {/* Left Side - Gender and Sexual Preference */}
                <div className="flex flex-col sm:flex-row gap-2">
                  {/* Gender Filter */}
                  <div className="w-full sm:w-36">
                    <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Gender</label>
                    <div className="space-y-0.5 border dark:border-gray-600 rounded-md px-2 py-1 bg-white dark:bg-gray-700">
                      {["Male", "Female", "Trans Male", "Trans Female", "Non-Binary", "Other"].map((gender) => (
                        <div key={gender} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`gender-${gender}`}
                            checked={advancedFilters.gender.includes(gender)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setAdvancedFilters(prev => ({ ...prev, gender: [...prev.gender, gender] }));
                              } else {
                                setAdvancedFilters(prev => ({ ...prev, gender: prev.gender.filter(g => g !== gender) }));
                              }
                            }}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <label htmlFor={`gender-${gender}`} className="text-sm text-gray-700 dark:text-white cursor-pointer">
                            {gender}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Sexual Preference Filter */}
                  <div className="w-full sm:w-40">
                    <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Sexual Preference</label>
                    <div className="space-y-0.5 border dark:border-gray-600 rounded-md px-2 py-1 bg-white dark:bg-gray-700">
                      {SEXUAL_PREFERENCE_OPTIONS.map((preference) => (
                        <div key={preference} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`pref-${preference}`}
                            checked={advancedFilters.sexualPreference.includes(preference)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setAdvancedFilters(prev => ({ ...prev, sexualPreference: [...prev.sexualPreference, preference] }));
                              } else {
                                setAdvancedFilters(prev => ({ ...prev, sexualPreference: prev.sexualPreference.filter(p => p !== preference) }));
                              }
                            }}
                            className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                          />
                          <label htmlFor={`pref-${preference}`} className="text-sm text-gray-700 dark:text-white cursor-pointer">
                            {preference}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Middle - User Type and Age Range (Stacked) */}
                <div className="flex flex-col gap-2">
                  {/* User Type Filter */}
                  <div className="w-full sm:w-32">
                    <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">User Type</label>
                    <div className="space-y-0.5 border dark:border-gray-600 rounded-md px-2 py-1 bg-white dark:bg-gray-700">
                      {["traveler", "local", "business"].map((type) => (
                        <div key={type} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={`usertype-${type}`}
                            checked={advancedFilters.userType.includes(type)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setAdvancedFilters(prev => ({ ...prev, userType: [...prev.userType, type] }));
                              } else {
                                setAdvancedFilters(prev => ({ ...prev, userType: prev.userType.filter(t => t !== type) }));
                              }
                            }}
                            className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                          />
                          <label htmlFor={`usertype-${type}`} className="text-sm text-gray-700 dark:text-white cursor-pointer capitalize">
                            {type}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Age Range */}
                  <div className="w-full sm:w-32">
                    <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Age Range</label>
                    <div className="space-y-1">
                      <Input 
                        type="number" 
                        placeholder="Min"
                        value={advancedFilters.minAge || ""}
                        onChange={(e) => setAdvancedFilters(prev => ({ ...prev, minAge: e.target.value ? parseInt(e.target.value) : undefined }))}
                        className="w-full text-sm px-2 py-1"
                      />
                      <Input 
                        type="number" 
                        placeholder="Max"
                        value={advancedFilters.maxAge || ""}
                        onChange={(e) => setAdvancedFilters(prev => ({ ...prev, maxAge: e.target.value ? parseInt(e.target.value) : undefined }))}
                        className="w-full text-sm px-2 py-1"
                      />
                    </div>
                  </div>
                </div>

                {/* Right Side - Traveler Type */}
                <div className="flex-1">
                  <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Traveler Type</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 border dark:border-gray-600 rounded-lg p-4 bg-white dark:bg-gray-700">
                    {BASE_TRAVELER_TYPES.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`traveler-type-${type}`}
                          checked={advancedFilters.travelerTypes.includes(type)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setAdvancedFilters(prev => ({ ...prev, travelerTypes: [...prev.travelerTypes, type] }));
                            } else {
                              setAdvancedFilters(prev => ({ ...prev, travelerTypes: prev.travelerTypes.filter(t => t !== type) }));
                            }
                          }}
                          className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                        />
                        <label htmlFor={`traveler-type-${type}`} className="text-sm text-gray-700 dark:text-white cursor-pointer">
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Location Filter - Use SmartLocationInput for consistency */}
              <div className="mb-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Location Filter</label>
                <div className="space-y-2">
                  <SmartLocationInput
                    city={locationFilter.city}
                    state={locationFilter.state}
                    country={locationFilter.country}
                    onLocationChange={(location) => {
                      setLocationFilter(location);
                      const fullLocation = `${location.city}${location.state ? `, ${location.state}` : ""}, ${location.country}`;
                      setAdvancedFilters(prev => ({ ...prev, location: fullLocation }));
                    }}
                    required={false}
                    placeholder={{
                      country: "Select country to filter by",
                      state: "Select state/region",
                      city: "Select city to filter by"
                    }}
                  />
                  <Select 
                    value={advancedFilters.location} 
                    onValueChange={(value) => setAdvancedFilters(prev => ({ ...prev, location: value === "clear" ? "" : value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Or select from your destinations" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="clear">Clear location filter</SelectItem>
                      {user?.hometown && (
                        <SelectItem value={user.hometown}>
                          🏠 {user.hometown} (Hometown)
                        </SelectItem>
                      )}
                      {user?.location && user.location !== user.hometown && (
                        <SelectItem value={user.location}>
                          📍 {user.location} (Current)
                      </SelectItem>
                      )}
                      {userTravelPlans?.filter(plan => plan.destination).map((plan, index) => (
                        <SelectItem key={index} value={plan.destination}>
                          ✈️ {plan.destination} (Travel Plan)
                        </SelectItem>
                      ))}
                      {user?.travelDestination && 
                       !userTravelPlans.some(plan => plan.destination === user.travelDestination) && (
                        <SelectItem value={user.travelDestination}>
                          🗺️ {user.travelDestination}
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Top Choices for Most Travelers - Popular Interests Widget */}
              <div className="mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Top Choices for Most Locals and Travelers</label>
                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 p-4 rounded-lg bg-gradient-to-r from-blue-100 to-orange-100 dark:from-blue-900 dark:to-orange-900 mb-4">
                  {[
                    "Single and Looking", "Coffee Culture", "Nightlife & Dancing", "Photography", 
                    "Meet Locals/Travelers", "Craft Beer & Breweries", "Local Food Specialties", "Hiking & Nature",
                    "City Tours & Sightseeing", "Street Art", "Cocktails & Bars", "Adventure Tours",
                    "Food Tours / Trucks", "Museums", "Rooftop Bars", "Local Hidden Gems",
                    "Beach Activities", "Fine Dining", "Yoga & Wellness", "Pub Crawls & Bar Tours",
                    "Walking Tours", "Happy Hour Deals", "Boat & Water Tours", "Brunch Spots",
                    "Live Music Venues", "Historical Tours", "Festivals & Events"
                  ].map((interest) => (
                    <button
                      key={interest}
                      onClick={() => {
                        if (advancedFilters.interests.includes(interest)) {
                          setAdvancedFilters(prev => ({ 
                            ...prev, 
                            interests: prev.interests.filter(i => i !== interest) 
                          }));
                        } else {
                          setAdvancedFilters(prev => ({ 
                            ...prev, 
                            interests: [...prev.interests, interest] 
                          }));
                        }
                      }}
                      className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                        advancedFilters.interests.includes(interest)
                          ? 'bg-gradient-to-r from-blue-500 to-orange-500 text-white'
                          : 'bg-white dark:bg-gray-700 text-black dark:text-white hover:bg-gray-100 dark:hover:bg-gray-600'
                      }`}
                    >
                      {interest}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interests Filter */}
              <div className="mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">All Available Interests</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 border dark:border-gray-600 rounded-lg p-3 bg-blue-50 dark:bg-gray-700 mb-2">
                  {getAllInterests().map((interest) => {
                    const displayText = interest.startsWith("**") && interest.endsWith("**") ? 
                      interest.slice(2, -2) : interest;
                    const isBold = interest.startsWith("**") && interest.endsWith("**");
                    
                    return (
                      <div key={interest} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`filter-interest-${interest}`}
                          checked={advancedFilters.interests.includes(interest)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setAdvancedFilters(prev => ({ ...prev, interests: [...prev.interests, interest] }));
                            } else {
                              setAdvancedFilters(prev => ({ ...prev, interests: prev.interests.filter(i => i !== interest) }));
                            }
                          }}
                          className="h-3 w-3 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label 
                          htmlFor={`filter-interest-${interest}`} 
                          className={`text-xs text-gray-700 dark:text-white cursor-pointer leading-tight ${isBold ? 'font-bold' : 'font-medium'}`}
                        >
                          {displayText}
                        </label>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Activities Filter */}
              <div className="mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Activities</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 border dark:border-gray-600 rounded-lg p-3 bg-green-50 dark:bg-gray-700 mb-2">
                  {getAllActivities().map((activity) => (
                    <div key={activity} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`filter-activity-${activity}`}
                        checked={advancedFilters.activities.includes(activity)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAdvancedFilters(prev => ({ ...prev, activities: [...prev.activities, activity] }));
                          } else {
                            setAdvancedFilters(prev => ({ ...prev, activities: prev.activities.filter(a => a !== activity) }));
                          }
                        }}
                        className="h-3 w-3 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label 
                        htmlFor={`filter-activity-${activity}`} 
                        className="text-xs text-gray-700 dark:text-white cursor-pointer leading-tight font-medium"
                      >
                        {activity}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Events Filter */}
              <div className="mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Events</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 border dark:border-gray-600 rounded-lg p-3 bg-purple-50 dark:bg-gray-700 mb-2">
                  {getAllEvents().map((eventType) => (
                    <div key={eventType} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`filter-event-${eventType}`}
                        checked={advancedFilters.events.includes(eventType)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAdvancedFilters(prev => ({ ...prev, events: [...prev.events, eventType] }));
                          } else {
                            setAdvancedFilters(prev => ({ ...prev, events: prev.events.filter(e => e !== eventType) }));
                          }
                        }}
                        className="h-3 w-3 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                      />
                      <label 
                        htmlFor={`filter-event-${eventType}`} 
                        className="text-xs text-gray-700 dark:text-white cursor-pointer leading-tight font-medium"
                      >
                        {eventType}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Military Status Filter */}
              <div className="mt-4">
                <label className="text-sm font-medium text-gray-700 dark:text-white mb-2 block">Military Status</label>
                <div className="grid grid-cols-2 gap-3 border dark:border-gray-600 rounded-lg p-3 bg-red-50 dark:bg-gray-700 mb-2">
                  {['Veteran', 'Active Duty'].map((status) => (
                    <div key={status} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`filter-military-${status}`}
                        checked={advancedFilters.militaryStatus?.includes(status) || false}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setAdvancedFilters(prev => ({ 
                              ...prev, 
                              militaryStatus: [...(prev.militaryStatus || []), status] 
                            }));
                          } else {
                            setAdvancedFilters(prev => ({ 
                              ...prev, 
                              militaryStatus: (prev.militaryStatus || []).filter(s => s !== status) 
                            }));
                          }
                        }}
                        className="h-4 w-4 text-red-600 focus:ring-red-500 border-gray-300 rounded"
                      />
                      <label 
                        htmlFor={`filter-military-${status}`} 
                        className="text-sm text-gray-700 dark:text-white cursor-pointer font-medium"
                      >
                        {status}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center items-center">
                <Button
                  variant="outline"
                  onClick={clearAdvancedFilters}
                  className="text-red-600 hover:text-red-700 border-red-300 hover:border-red-400 w-full sm:w-auto"
                >
                  <X className="w-4 h-4 mr-2" />
                  Clear All Filters
                </Button>
                
                <Button
                  className="bg-gradient-to-r from-blue-500 to-orange-500 text-white hover:from-blue-600 hover:to-orange-600 w-full sm:w-auto"
                  onClick={handleAdvancedSearch}
                  disabled={isAdvancedSearching}
                >
                  <Search className="w-4 h-4 mr-2" />
                  {isAdvancedSearching ? "Searching..." : "Search Now"}
                </Button>
              </div>
            </Card>

            {/* Search Results */}
            {hasAdvancedSearched && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-blue-600" />
                    Search Results ({advancedSearchResults.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isAdvancedSearching ? (
                    <div className="space-y-4">
                      {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="flex items-center space-x-4">
                          <Skeleton className="h-12 w-12 rounded-full" />
                          <div className="space-y-2">
                            <Skeleton className="h-4 w-[200px]" />
                            <Skeleton className="h-4 w-[150px]" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : advancedSearchResults.length > 0 ? (
                    <ResponsiveUserGrid 
                      users={advancedSearchResults}
                      title={`Found ${advancedSearchResults.length} ${advancedSearchResults.length === 1 ? 'person' : 'people'} matching your filters`}
                    />
                  ) : (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2 text-black dark:text-white">No users found</h3>
                      <p className="text-gray-600 dark:text-white mb-4">
                        Try adjusting your search criteria or clearing some filters.
                      </p>
                      <Button variant="outline" onClick={clearAdvancedFilters}>
                        Clear All Filters
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>

      {/* Connect Modal Widget */}
      <ConnectModal 
        isOpen={showConnectModal}
        onClose={() => {
          console.log('ConnectModal closing');
          setShowConnectModal(false);
        }}
        userTravelPlans={userTravelPlans || []}
        defaultLocationMode={connectModalMode}
        currentUser={user}
      />
    </div>
  );
}