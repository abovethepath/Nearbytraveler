// Simple back button utility that works like every website
export function goBack() {
  // Just use browser back - this is what every website does
  window.history.back();
}