import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Star, ThumbsUp, Shield, User, MessageCircle } from 'lucide-react';
import { useAuth } from '@/App';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/api';

interface Reference {
  id: number;
  reviewerId: number;
  revieweeId: number;
  experience: 'positive' | 'neutral' | 'negative';
  content: string;
  createdAt: string;
  reviewer: {
    id: number;
    name: string;
    username: string;
    profileImage: string | null;
  };
}

export function ReferenceSystem({ isOwnProfile = false, userId }: { isOwnProfile?: boolean; userId?: number }) {
  const { user } = useAuth();
  const [showWriteReference, setShowWriteReference] = useState(false);
  const [isEditingReference, setIsEditingReference] = useState(false);
  const [referenceData, setReferenceData] = useState({
    experience: 'positive' as const,
    content: ''
  });
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: references = [] } = useQuery<Reference[]>({
    queryKey: [`/api/users/${userId}/references`],
    enabled: !!(userId)
  });

  // Check if user has already written a reference for this person
  const { data: existingReferenceData } = useQuery({
    queryKey: [`/api/user-references/check`, user?.id, userId],
    queryFn: async () => {
      if (!user?.id || !userId || isOwnProfile) return { exists: false, reference: null };
      const response = await fetch(`/api/user-references/check?reviewerId=${user.id}&revieweeId=${userId}`);
      if (!response.ok) throw new Error('Failed to check existing reference');
      const data = await response.json();
      console.log('🔍 REFERENCE CHECK RESULT:', { 
        reviewerId: user.id, 
        revieweeId: userId, 
        exists: data.exists, 
        hasReference: !!data.reference,
        data 
      });
      return data;
    },
    enabled: !!(user?.id && userId && !isOwnProfile)
  });

  const submitReference = useMutation({
    mutationFn: async (data: { experience: string; content: string }) => {
      if (!data.content || data.content.trim().length === 0) {
        throw new Error('Reference content is required');
      }

      if (!user?.id || !userId) {
        throw new Error('User authentication required');
      }

      const method = isEditingReference ? 'PUT' : 'POST';
      const url = isEditingReference 
        ? `/api/user-references/${existingReferenceData?.reference?.id}`
        : '/api/user-references';

      const response = await apiRequest(method, url, {
        revieweeId: userId,
        reviewerId: user.id,
        experience: data.experience,
        content: data.content.trim()
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('Reference submission error:', errorData);
        throw new Error(errorData || 'Failed to submit reference');
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}/references`] });
      queryClient.invalidateQueries({ queryKey: [`/api/user-references/check`, user?.id, userId] });
      setShowWriteReference(false);
      setIsEditingReference(false);
      setReferenceData({ experience: 'positive', content: '' });
      toast({
        title: isEditingReference ? 'Reference Updated' : 'Reference Submitted',
        description: isEditingReference ? 'Your reference has been updated successfully.' : 'Your reference has been submitted successfully.',
      });
    },
    onError: (error: any) => {
      console.error('Reference submission error:', error);
      toast({
        title: 'Error',
        description: error?.message || 'Failed to submit reference. Please try again.',
        variant: 'destructive',
      });
    }
  });

  const getExperienceColor = (experience: string) => {
    switch (experience) {
      case 'positive':
        return 'text-green-700 bg-green-100 dark:text-green-300 dark:bg-green-900/30';
      case 'negative':
        return 'text-red-700 bg-red-100 dark:text-red-300 dark:bg-red-900/30';
      default:
        return 'text-yellow-700 bg-yellow-100 dark:text-yellow-300 dark:bg-yellow-900/30';
    }
  };

  const handleSubmitReference = () => {
    if (!referenceData.content.trim() || referenceData.content.trim().length < 10) {
      toast({
        title: "Validation Error",
        description: "Please write at least 10 characters for your reference.",
        variant: "destructive",
      });
      return;
    }
    submitReference.mutate(referenceData);
  };

  const handleWriteReference = () => {
    if (!user?.id) {
      toast({
        title: 'Authentication Required',
        description: 'Please log in to write a reference.',
        variant: 'destructive'
      });
      return;
    }

    if (existingReferenceData?.exists && existingReferenceData.reference) {
      setIsEditingReference(true);
      setReferenceData({
        experience: existingReferenceData.reference.experience || 'positive',
        content: existingReferenceData.reference.content || ''
      });
    } else {
      setIsEditingReference(false);
      setReferenceData({ experience: 'positive', content: '' });
    }
    setShowWriteReference(!showWriteReference);
  };

  return (
    <div className="space-y-6">
      {/* References Summary Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Community References
            </CardTitle>
            {!isOwnProfile && (
              <Button
                onClick={handleWriteReference}
                size="sm"
                className="bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600"
              >
                {(() => {
                  const buttonText = showWriteReference ? 'Cancel' : (existingReferenceData?.exists ? 'Edit Reference' : 'Write Reference');
                  console.log('🔧 BUTTON TEXT LOGIC:', { 
                    showWriteReference, 
                    existsValue: existingReferenceData?.exists, 
                    existingData: existingReferenceData,
                    buttonText 
                  });
                  return buttonText;
                })()}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{references.length}</div>
              <div className="text-sm text-gray-500">Total References</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {references.filter((r: Reference) => r.experience === 'positive').length}
              </div>
              <div className="text-sm text-gray-500">Positive</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-yellow-600">
                {references.filter((r: Reference) => r.experience === 'neutral').length}
              </div>
              <div className="text-sm text-gray-500">Neutral</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {references.filter((r: Reference) => r.experience === 'negative').length}
              </div>
              <div className="text-sm text-gray-500">Negative</div>
            </div>
          </div>

          {showWriteReference && (
            <div className="space-y-4 p-4 border rounded-lg bg-gray-50 dark:bg-gray-800 mb-6">
              <h4 className="font-semibold text-lg">{isEditingReference ? 'Edit Your Reference' : 'Write a Reference'}</h4>
              {isEditingReference && (
                <p className="text-sm text-blue-600 dark:text-blue-400 mb-4">
                  You can only have one reference per person. Updating this will replace your previous reference.
                </p>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 block">
                  Experience Type *
                </label>
                <select
                  value={referenceData.experience}
                  onChange={(e) => setReferenceData(prev => ({ ...prev, experience: e.target.value as any }))}
                  className="w-full p-3 border rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white min-h-[48px]"
                  required
                >
                  <option value="positive">👍 Positive Experience</option>
                  <option value="neutral">😐 Neutral Experience</option>
                  <option value="negative">👎 Negative Experience</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 block">
                  Your Reference *
                </label>
                <textarea
                  value={referenceData.content}
                  onChange={(e) => setReferenceData(prev => ({ ...prev, content: e.target.value }))}
                  className="w-full p-3 border rounded-md bg-white dark:bg-gray-700 dark:border-gray-600 dark:text-white min-h-[120px] resize-none"
                  placeholder="Share your experience with this person... (minimum 10 characters)"
                  required
                  minLength={10}
                  maxLength={500}
                />
                <div className="text-xs text-gray-500 dark:text-gray-400 text-right">
                  {referenceData.content.length}/500 characters
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <Button
                  onClick={() => {
                    setShowWriteReference(false);
                    setIsEditingReference(false);
                    setReferenceData({ experience: 'positive', content: '' });
                  }}
                  variant="outline"
                  className="w-full sm:w-auto min-h-[48px]"
                  type="button"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmitReference}
                  disabled={submitReference.isPending || !referenceData.content.trim() || referenceData.content.trim().length < 10}
                  className="w-full sm:w-auto min-h-[48px] bg-gradient-to-r from-orange-500 to-blue-500 hover:from-orange-600 hover:to-blue-600"
                  type="button"
                >
                  {submitReference.isPending ? 'Submitting...' : (isEditingReference ? 'Update Reference' : 'Submit Reference')}
                </Button>
              </div>
            </div>
          )}

          {references.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <User className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No references yet</p>
              <p className="text-sm">
                {isOwnProfile 
                  ? "Connect with community members to receive your first reference"
                  : "Be the first to write a reference for this member"
                }
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {references.map((reference: Reference) => (
                <div key={reference.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-orange-500 rounded-full flex items-center justify-center text-white font-semibold">
                      {reference.reviewer?.username?.charAt(0)?.toUpperCase() || 'U'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <div className="font-semibold">@{reference.reviewer?.username || 'Unknown User'}</div>
                        <Badge 
                          variant="outline" 
                          className={`text-xs px-1 py-0 flex-shrink-0 ml-2 ${getExperienceColor(reference.experience)} border-current`}
                        >
                          {reference.experience}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(reference.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div>
                    <p className="text-gray-600 dark:text-gray-400">{reference.content}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}